| scenario | engine | population_size | num_generations | runs | HV | IGD | Runtime(s) |
|---|---|---|---|---|---|---|---|
| Main (No Surrogate) | deap_nsga2 | 20 | 4 | 1 | 36526440.933 ± 0.000 | 0.000 ± 0.000 | 0.560 ± 0.000 |
